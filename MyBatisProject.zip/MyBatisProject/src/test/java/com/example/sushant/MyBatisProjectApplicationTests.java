package com.example.sushant;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MyBatisProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
